const data={
ar:{dir:"rtl",brand:"مراس",counter:"السؤال",score:"النقاط",next:"السؤال التالي ←",correct:"✅ إجابة صحيحة!",wrong:"❌ إجابة خاطئة — الإجابة الصحيحة باللون الأخضر.",end:"انتهى الاختبار!",restart:"إعادة الاختبار",message1:"ممتاز! 🔥",message2:"نتيجة جيدة، واصل التدريب 💪",message3:"لا بأس، حاول مرة أخرى وستتحسن! 🌟"},
fr:{dir:"ltr",brand:"Miras",counter:"Question",score:"Score",next:"Question suivante →",correct:"✅ Bonne réponse !",wrong:"❌ Mauvaise réponse — la bonne réponse est en vert.",end:"Quiz terminé !",restart:"Recommencer",message1:"Excellent ! 🔥",message2:"Bon résultat, continue ! 💪",message3:"Pas grave, réessaie ! 🌟"}
};
const questions=[
{ar:{q:"ما هي عاصمة تونس؟",o:["الجزائر","تونس","الرباط"]},fr:{q:"Quelle est la capitale de la Tunisie ?",o:["Alger","Tunis","Rabat"]},a:1},
{ar:{q:"كم عدد أيام الأسبوع؟",o:["5","6","7"]},fr:{q:"Combien de jours compte une semaine ?",o:["5","6","7"]},a:2},
{ar:{q:"ما هو الكوكب المعروف بالكوكب الأحمر؟",o:["المريخ","الزهرة","المشتري"]},fr:{q:"Quelle planète est appelée la planète rouge ?",o:["Mars","Vénus","Jupiter"]},a:0},
{ar:{q:"كم يساوي 5 × 6؟",o:["25","30","35"]},fr:{q:"Combien font 5 × 6 ?",o:["25","30","35"]},a:1},
{ar:{q:"ما هو أكبر محيط في العالم؟",o:["الأطلسي","الهندي","الهادئ"]},fr:{q:"Quel est le plus grand océan du monde ?",o:["Atlantique","Indien","Pacifique"]},a:2}
];
let lang="ar",current=0,score=0,answered=false;
const $=id=>document.getElementById(id);
function render(){
 const t=data[lang], item=questions[current][lang]; answered=false;
 document.documentElement.lang=lang;document.documentElement.dir=t.dir;
 $("lang").textContent=lang==="ar"?"FR":"AR";
 $("counter").textContent=`${t.counter} ${current+1} / ${questions.length}`;
 $("scoreText").textContent=`${t.score}: ${score}`;
 $("bar").style.width=`${current/questions.length*100}%`;
 $("question").textContent=item.q;$("feedback").textContent="";
 $("next").textContent=t.next;$("next").classList.remove("show");
 $("answers").innerHTML="";
 item.o.forEach((text,i)=>{let b=document.createElement("button");b.className="answer";b.textContent=text;b.onclick=()=>choose(i);$("answers").appendChild(b)});
}
function choose(i){
 if(answered)return; answered=true; const item=questions[current],t=data[lang];
 [...$("answers").children].forEach((b,n)=>{b.disabled=true;if(n===item.a)b.classList.add("correct");if(n===i&&i!==item.a)b.classList.add("wrong")});
 if(i===item.a){score++;$("feedback").textContent=t.correct}else $("feedback").textContent=t.wrong;
 $("scoreText").textContent=`${t.score}: ${score}`;$("next").classList.add("show");
}
$("next").onclick=()=>{current++;if(current>=questions.length)finish();else render()};
function finish(){
 const t=data[lang],pct=score/questions.length*100;
 $("quizCard").style.display="none";$("result").style.display="block";
 $("resultTitle").textContent=t.end;$("finalScore").textContent=`${score} / ${questions.length}`;
 $("finalMessage").textContent=pct===100?t.message1:pct>=60?t.message2:t.message3;$("restart").textContent=t.restart;
}
$("restart").onclick=()=>{current=0;score=0;$("result").style.display="none";$("quizCard").style.display="block";render()};
$("lang").onclick=()=>{lang=lang==="ar"?"fr":"ar";render()};
render();
